i = rgb2gray(imread('Picture10.jpg'));

v1  = imnoise(i,'salt & pepper',0.03);
v2  = imnoise(i,'salt & pepper',0.06);
v3  = imnoise(i,'salt & pepper',0.07);
v4  = imnoise(i,'salt & pepper',0.12);
v5  = imnoise(i,'salt & pepper',0.15);
v6  = imnoise(i,'salt & pepper',0.18);
v7  = imnoise(i,'salt & pepper',0.21);
v8  = imnoise(i,'salt & pepper',0.24);
v9  = imnoise(i,'salt & pepper',0.27);
v10  = imnoise(i,'salt & pepper',0.30);

imwrite(v1,'var1.jpg');
imwrite(v2,'var2.jpg');
imwrite(v3,'var3.jpg');
imwrite(v4,'var4.jpg');
imwrite(v5,'var5.jpg');
imwrite(v6,'var6.jpg');
imwrite(v7,'var7.jpg');
imwrite(v8,'var8.jpg');
imwrite(v9,'var9.jpg');
imwrite(v10,'var10.jpg');

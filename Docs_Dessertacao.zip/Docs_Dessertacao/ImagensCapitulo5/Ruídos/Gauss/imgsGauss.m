i = rgb2gray(imread('Picture10.jpg'));

v1  = imnoise(i,'gaussian',0,0.01);
v2  = imnoise(i,'gaussian',0,0.02);
v3  = imnoise(i,'gaussian',0,0.03);
v4  = imnoise(i,'gaussian',0,0.04);
v5  = imnoise(i,'gaussian',0,0.05);
v6  = imnoise(i,'gaussian',0,0.06);
v7  = imnoise(i,'gaussian',0,0.07);
v8  = imnoise(i,'gaussian',0,0.08);
v9  = imnoise(i,'gaussian',0,0.09);
v10  = imnoise(i,'gaussian',0,0.10);

imwrite(v1,'var1.jpg');
imwrite(v2,'var2.jpg');
imwrite(v3,'var3.jpg');
imwrite(v4,'var4.jpg');
imwrite(v5,'var5.jpg');
imwrite(v6,'var6.jpg');
imwrite(v7,'var7.jpg');
imwrite(v8,'var8.jpg');
imwrite(v9,'var9.jpg');
imwrite(v10,'var10.jpg');

function resul = addRuido2(img)
    % 2 iterações
    r1   = imnoise(img,'poisson');
    resul  = imnoise(r1,'poisson');
        
end
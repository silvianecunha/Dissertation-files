i = rgb2gray(imread('Picture10.jpg'));

v1  = addRuido(i);
v2  = addRuido2(i);
v3  = addRuido3(i);
v4  = addRuido4(i);
v5  = addRuido5(i);
v6  = addRuido6(i);
v7  = addRuido7(i);
v8  = addRuido8(i);
v9  = addRuido9(i);
v10  = addRuido10(i);

imwrite(v1,'var1.jpg');
imwrite(v2,'var2.jpg');
imwrite(v3,'var3.jpg');
imwrite(v4,'var4.jpg');
imwrite(v5,'var5.jpg');
imwrite(v6,'var6.jpg');
imwrite(v7,'var7.jpg');
imwrite(v8,'var8.jpg');
imwrite(v9,'var9.jpg');
imwrite(v10,'var10.jpg');

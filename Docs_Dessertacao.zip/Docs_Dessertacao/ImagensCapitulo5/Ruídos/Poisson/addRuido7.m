function resul = addRuido7(img)
    % 7 iterações
    r1   = imnoise(img,'poisson'); 
    r2   = imnoise(r1, 'poisson');
    r3   = imnoise(r2, 'poisson'); 
    r4   = imnoise(r3, 'poisson');
    r5   = imnoise(r4, 'poisson'); 
    r6   = imnoise(r5, 'poisson');
    resul   = imnoise(r6, 'poisson'); 
    
end
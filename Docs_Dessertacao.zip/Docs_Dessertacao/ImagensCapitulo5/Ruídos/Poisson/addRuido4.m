function resul = addRuido4(img)
    % 4 iterações
    r1   = imnoise(img,'poisson');
    r2   = imnoise(r1, 'poisson');
    r3   = imnoise(r2, 'poisson');
    resul  = imnoise(r3,'poisson');
        
end
function resul = addRuido3(img)
    % 3 iterações
    r1   = imnoise(img,'poisson');
    r2   = imnoise(r1, 'poisson');
    resul  = imnoise(r2,'poisson');
        
end
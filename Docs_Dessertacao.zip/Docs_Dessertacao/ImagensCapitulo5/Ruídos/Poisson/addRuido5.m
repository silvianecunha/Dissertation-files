function resul = addRuido5(img)
    % 5 iterações
    r1   = imnoise(img,'poisson');
    r2   = imnoise(r1, 'poisson');
    r3   = imnoise(r2, 'poisson');
    r4   = imnoise(r3, 'poisson');
    resul  = imnoise(r4,'poisson');
end
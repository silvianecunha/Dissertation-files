i = rgb2gray(imread('Picture10.jpg'));

v1  = imnoise(i,'speckle',0.001);
v2  = imnoise(i,'speckle',0.004);
v3  = imnoise(i,'speckle',0.006);
v4  = imnoise(i,'speckle',0.008);
v5  = imnoise(i,'speckle',0.02);
v6  = imnoise(i,'speckle',0.04);
v7  = imnoise(i,'speckle',0.06);
v8  = imnoise(i,'speckle',0.08);
v9  = imnoise(i,'speckle',0.10);
v10  = imnoise(i,'speckle',0.15);

imwrite(v1,'var1.jpg');
imwrite(v2,'var2.jpg');
imwrite(v3,'var3.jpg');
imwrite(v4,'var4.jpg');
imwrite(v5,'var5.jpg');
imwrite(v6,'var6.jpg');
imwrite(v7,'var7.jpg');
imwrite(v8,'var8.jpg');
imwrite(v9,'var9.jpg');
imwrite(v10,'var10.jpg');

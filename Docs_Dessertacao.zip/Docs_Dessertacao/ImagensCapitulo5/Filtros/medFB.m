function imgFiltrada = medFB(image)

i = medfilt2(image,[3 3]);
forwardBackward = fb(i);

imgFiltrada = forwardBackward;

end
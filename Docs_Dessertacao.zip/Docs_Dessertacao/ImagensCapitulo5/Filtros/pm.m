function diff_im = pm(image)
% Perona-Malik (ÂSMC) (NOVO)

im = double (image);
diff_im1 = im;

num_iter = 10; % (escala)
delta_t = 0.25; % (lambda)
kappa = 15;

dx = 1;
dy = 1;

hN = [0 1 0; 0 -1 0; 0 0 0];
hS = [0 0 0; 0 -1 0; 0 1 0];
hE = [0 0 0; 0 -1 1; 0 0 0];
hW = [0 0 0; 1 -1 0; 0 0 0];

% Anisotropic diffusion.
for t = 1:num_iter
    
    nablaN = imfilter(diff_im1,hN,'conv');
    nablaS = imfilter(diff_im1,hS,'conv');
    nablaW = imfilter(diff_im1,hW,'conv');
    nablaE = imfilter(diff_im1,hE,'conv');
 
    % 1ª equação
%     cN = exp(-(nablaN/kappa).^2);
%     cS = exp(-(nablaS/kappa).^2);
%     cW = exp(-(nablaW/kappa).^2);
%     cE = exp(-(nablaE/kappa).^2);
            
    % 2ª equação:
    cN = 1./(1 + (nablaN/kappa).^2);
    cS = 1./(1 + (nablaS/kappa).^2);
    cW = 1./(1 + (nablaW/kappa).^2);
    cE = 1./(1 + (nablaE/kappa).^2);
   
    diff_im2 = diff_im1 + delta_t*( (1/(dy^2))*cN.*nablaN + (1/(dy^2))*cS.*nablaS +  (1/(dx^2))*cW.*nablaW + (1/(dx^2))*cE.*nablaE) ;
end

diff_im = uint8(diff_im2);

end
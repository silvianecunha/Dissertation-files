% Filtros
i = rgb2gray(imread('Picture10.jpg'));
r = addRuido10(i);
imwrite(r,'1_ruido.jpg');

% Média
f1  = imfilter(r,([1 1 1;1 1 1; 1 1 1]*1/9));
imwrite(f1,'2_media.jpg');

% Mediana
f2 = medfilt2(r,[3 3]);
imwrite(f2,'3_mediana.jpg');

% Wiener
f3 = wiener2(r,[3 3]);
imwrite(f3,'4_wiener.jpg');

% Perona Malik
f4 = pm(r);
imwrite(f4,'5_peronaMalik.jpg');

% Forward Backward
f5 = fb(r);
imwrite(f5,'6_forwardBackward.jpg');

% Mediana + PM
f6 = medPM(r);
imwrite(f6,'7_medPM.jpg');

% Mediana + FB
f7 = medFB(r);
imwrite(f7,'8_medFB.jpg');

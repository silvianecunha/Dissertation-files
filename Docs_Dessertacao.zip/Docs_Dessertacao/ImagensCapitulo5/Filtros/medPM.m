function imgFiltrada = medPM(image)

i = medfilt2(image,[3 3]);
peronaMalik = pm(i);

imgFiltrada = peronaMalik;

end
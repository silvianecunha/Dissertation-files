function diff_im = fb(image)
% Forward-Backward (ÂSMC)

im = im2double(image); 
diff_im1 = im;

hN = [0 1 0; 0 -1 0; 0 0 0];
hS = [0 0 0; 0 -1 0; 0 1 0];
hE = [0 0 0; 0 -1 1; 0 0 0];
hW = [0 0 0; 1 -1 0; 0 0 0];

num_iter = 10; % (escala)
delta = 0.1; % <- ??
p = 1.1; % p = 1.1; (incluído)
delta_t = 0.25; % (incluído)

for i = 1:num_iter

nablaN = imfilter(diff_im1,hN,'conv');
nablaS = imfilter(diff_im1,hS,'conv');   
nablaW = imfilter(diff_im1,hW,'conv');
nablaE = imfilter(diff_im1,hE,'conv');  

cN = 1./(1 + (nablaN).^2);
cS = 1./(1 + (nablaS).^2);
cW = 1./(1 + (nablaW).^2);
cE = 1./(1 + (nablaE).^2);
 
gN = delta *((double(abs(nablaN))+ 0.1).^(p-2));
gS = delta *((double(abs(nablaS))+ 0.1).^(p-2));
gW = delta *((double(abs(nablaW))+ 0.1).^(p-2));
gE = delta *((double(abs(nablaE))+ 0.1).^(p-2));

aN = cN + gN;
aS = cS + gS;
aE = cE + gE;
aW = cW + gW;

m = delta_t*( (aN.*nablaN) + (aS.*nablaS) + (aE.*nablaE) + (aW.*nablaW));

diff_im = diff_im1 + m;
%imshow(diff_im2,[])
%title(num2str(i))
%size(diff_im2)
% imshow(diff_im2,[]);
%im_t(:,:,i) = diff_im2;
% diff_im = diff_im2;

end

%diff_im = uint8(diff_im2);
%diff_im = uint8(255 * mat2gray(diff_im));

end
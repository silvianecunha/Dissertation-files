%% Phase Correlation, SIFT e SURF - exemplo de aplicação do ruído, filtragem e conferência de padrão ouro.

%% ----------------------------------------------------------------------- %%
% Leitura da imagem da imagem e conversão para a escala de cinza:
i1 = rgb2gray(imread('imagem1.jpg'));
i2 = rgb2gray(imread('imagem2.jpg')); 

%% ------------------------------------------------------------------------------- %%
% Aplicação de ruído (escolher o ruído):
r  = imnoise(i2,'salt & pepper',0.03);   
r  = imnoise(i2,'gaussian',0,0.01);
r  = addRuido(i2);
r  = imnoise(i2,'speckle',0.001);

%% ------------------------------------------------------------------------------- %%
% Aplicação de filtro (escolher o filtro):

% Média
f  = imfilter(r,([1 1 1;1 1 1; 1 1 1]*1/9));

% Mediana
f = medfilt2(r,[3 3]);

% Wiener
f = wiener2(r,[3 3]);

% Perona Malik
f = pm(r);

% Forward-Backward
f = fb(r);

% Mediana + PM
f = medPM(r);

% Mediana + FB
f = medFB(r);

%% ------------------------------------------------------------------------------- %%
% Aplicação do método de mosaico e conferência do padrão ouro:

% Correlação de fase:
[x,y] = phaseCorrelation(i1,f);
fprintf('%d %d',x1,y1);
if(x==1)&&(y==1120)
    k = 1;
    else 
       k = 0;    
end

% Sift (necessário a instalação do VLFeat 0.9.21 (http://www.vlfeat.org/index.html):
[x,y] = siftCorrelation(i1,f);
fprintf('%d %d',x1,y1);
if(x==1)&&(y==1120)
    k = 1;
    else 
       k = 0;    
end

% Surf:
[x,y] = surfCorrelation(i1,f);
    fprintf('%d %d \n',x,y);
    a = [x,y];
    b = [1,1120];
    if isequal (a,b)
        k = 1;
        else 
           k = 0;    
    end


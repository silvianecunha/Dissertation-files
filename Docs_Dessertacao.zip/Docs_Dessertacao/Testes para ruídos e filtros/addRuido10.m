function resul = addRuido10(img)
    % 10 iterações  
    r1  = imnoise(img,'poisson');
    r2  = imnoise(r1,'poisson');
    r3  = imnoise(r2,'poisson');
    r4  = imnoise(r3,'poisson');
    r5  = imnoise(r4,'poisson');
    r6  = imnoise(r5,'poisson');
    r7  = imnoise(r6,'poisson');
    r8  = imnoise(r7,'poisson');
    r9  = imnoise(r8,'poisson');
    resul = imnoise(r9,'poisson'); 
end
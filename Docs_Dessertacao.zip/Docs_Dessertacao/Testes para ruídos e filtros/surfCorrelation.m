function [X,Y] = surfCorrelation(i1,i2)
% ÂSMC

% I1 = (I1-min(I1(:)))/(max(I1(:))-min(I1(:)));
% I2 = (I2-min(I2(:)))/(max(I2(:))-min(I2(:)));

I1 = uint8(i1);
I2 = uint8(i2);

points1 = detectSURFFeatures(I1);
points2 = detectSURFFeatures(I2);
%subplot(1,2,1), imshow(I1)
%subplot(1,2,2), imshow(I2)
%drawnow
%size(I1)
%size(I2)

%imwrite(I1,'imone.jpg');
%imwrite(I2,'imtwo.jpg')
%size(points1)
%size(points2)
%points1 = pots1.selectStrongest(10);
%points2 = points2.selectStrongest(10);


[f1,vpts1] = extractFeatures(I1,points1);
[f2,vpts2] = extractFeatures(I2,points2);

[indexPairs,matchmetric]  = matchFeatures(f1,f2); 
matchedPoints1 = vpts1(indexPairs(:,1));
matchedPoints2 = vpts2(indexPairs(:,2));
%ax = axes;
%figure; showMatchedFeatures(I1,I2,matchedPoints1,matchedPoints2,'montage','Parent',ax);
%legend('matched points 1','matched points 2');

p1 = round(matchedPoints1.Location);
p2 = round(matchedPoints2.Location);
[minIdx, idx] = min(matchmetric);
Y = abs(p1(idx,1) -p2(idx,1))+1;
X = abs(p1(idx,2) -p2(idx,2))+1;
end
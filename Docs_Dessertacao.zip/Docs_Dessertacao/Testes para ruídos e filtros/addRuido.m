function resul = addRuido(img)
    % 1 iteração
    resul  = imnoise(img,'poisson');
        
end
function [X,Y] = siftCorrelation(im1, im2)
% SIFT_MOSAIC Demonstrates matching two images using SIFT and RANSAC
%
%   SIFT_MOSAIC demonstrates matching two images based on SIFT
%   features and RANSAC and computing their mosaic.
%
%   SIFT_MOSAIC by itself runs the algorithm on two standard test
%   images. Use SIFT_MOSAIC(IM1,IM2) to compute the mosaic of two
%   custom images IM1 and IM2.

% AUTORIGHTS

% if nargin == 0
%   im1 = imread(fullfile(vl_root, 'data', 'river1.jpg')) ;
%   im2 = imread(fullfile(vl_root, 'data', 'river2.jpg')) ;
% end

% make single
im1 = im2single(im1) ;
im2 = im2single(im2) ;

% make grayscale
if size(im1,3) > 1, im1g = rgb2gray(im1) ; else im1g = im1 ; end
if size(im2,3) > 1, im2g = rgb2gray(im2) ; else im2g = im2 ; end

% --------------------------------------------------------------------
%                                                         SIFT matches
% --------------------------------------------------------------------

[f1,d1] = vl_sift(im1g) ;
[f2,d2] = vl_sift(im2g) ;

[matches, scores] = vl_ubcmatch(d1,d2) ;


[minScore,minId]= min(scores);
%matches(minId,1)
%matches(minId,2)
p1 = f1(1:2,matches(1,minId));
p2 = f2(1:2,matches(2,minId));

Y = abs(round(p1(1) - p2(1)))+1;
X = abs(round(p1(2) - p2(2)))+1;

end
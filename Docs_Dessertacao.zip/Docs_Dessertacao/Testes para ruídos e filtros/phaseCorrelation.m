function [X1,Y1] = phaseCorrelation(diff1,B1)

	%% Algoritmo para alinhar duas imagens utilizando o método de correlação de fase.

	%% Etapa 1: Ler duas imagens:
	imagem1 = imread('img1.tif');
	imagem2 = imread('img2.tif');

	% Converter para escala de cinza. Pixels com valores de 0 a 255.
	im1 = rgb2gray(imagem1);
	im2 = rgb2gray(imagem2);

	%% Etapa 2: Calcular a transformada de Fourier de ambas as imagens:
	% Calcula a "2-D transformada rápida de Fourier" de ambas as imagens com a função "fft2".
	% Em seguida, com a função "fftshift" desloca os componentes de freqüência zero para o 
	% centro da matriz. É útil para visualizar uma transformada de Fourier com o componente 
	% de frequência zero no meio do espectro.
	F1 = fftshift(fft2(im1));   
	F2 = fftshift(fft2(im2));

	% Calcular as dimensões das imagens (matrizes):
	% r = número de linhas da imagem; 
	% c = número de colunas da imagem;
	% d = dimensão da imagem.
	[r1, c1, d1] = size(im1);
	[r2, c2, d2] = size(im2);

	%% Etapa 3: Calcular o cross power spectrum das imagens:
	% Multiplica a 2D-FFT da 1ª imagem pelo complexo conjugado "conj" da 2ª imagem:
	F = F1.*conj(F2);
	% Divide o resultado anterior por ele mesmo, mas este segundo termo é normalizado "abs":
	R = F./abs(F);

	%% Etapa 4: Obter a correlação cruzada normalizada aplicando a 
	% transformada inversa de Fourier "ifft2" no cross power spectrum R:
	mag = (ifft2(R));

	%% Etapa 5: Localizar o pico (valor máximo de "mag"). Coordenadas do ponto máximo:
	[X1, Y1] = find((mag == (max(max(mag)))));

end
